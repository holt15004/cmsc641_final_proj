#################################################################################################################
#
# Cryptocurrency Exchange Data Collector
# James Holt
# Created for UMD CMSC641 Fall 2017 final project.
#
#################################################################################################################
#
# This program uses public APIs available from four cryptocurrency exchanges to query and store exchange rate data
# for six different currency pairs. Not all exchanges offer all currency pairs, so pairs collected varies by exchange.
#
# The program repeats all the queries approximately once per minute, adds a timestamp to each (because some exchanges
# do not include timestamps in their results) and appends the results to a file.  There is a separate file for each
# exchange/currency pair combination.  If the files do not exist they will be created.  If they exist results will be
# appended to the end of the file. This program runs until killed, though it can be modified to run for a specified
# number of iterations by uncommenting a section of code at the bottom of the loop. It can be stopped and restarted
# without loss of any collected data.
#
# Cryptocurrencies we are looking at, with their symbols:
#       Bitcoin      : btc, BTC, or XBT
#       Bitcoin Cash : bch, BCH, or BCC
#       Ethereum     : eth, or ETH
#       Dash         : dsh, or DASH
#       Ripple       : xrp, or XRP
#       Litecoin     : ltc, or LTC
#
# From each exchange get (if available) exchange information for the following currency pairs:
#
#       bch - btc
#       eth - btc
#       dsh - btc
#       xrp - btc
#       ltc - btc
#       bch - eth
#
# Exchange information for a currency pair includes "ask" and "bid".  It contains other information, but these two
# items are the only ones we will need for our analysis.
#
# Error Handling:
#     This program catches and handles a variety of errors, including timeout of HTTP requests and other errors that might
#     occur from an HTTP request.  It only writes data to a result file on successful HTTP request.
#     It also catches a kill signal and closes all open files before stopping.
#
# All actions are logged to a log file for debugging or auditing.
#

import time
import os
import requests

from datetime import datetime

# function to log data to log file
def log(s,l):
    ts = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
    l.write(ts + ': ' + s + '\n')
    l.flush()

# given a url and a target file, get data from the URL's API and appdend to the file
def getTickerAndWrite(u,f):
    log('polling URL: '+u, logfile)
    ts = datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')

    try:
        r = requests.request("GET", u, timeout=6)
        if r.status_code == 200:
           f.write(ts + ': ' + r.text + '\n')
           f.flush()
        else:
            log('error on GET, non-200 code: '+str(r.status_code), logfile)
    except requests.exceptions.RequestException as e:
        log('error on GET: '+str(e), logfile)


# check if data directory exists.  if not, create it
if not os.path.exists('./data'):
        os.mkdir('./data')

# open logfile and start logging
logfile = open('./data/log.txt','a+')

log('starting...',logfile)
log('opened logfile', logfile)


# list of exchanges, with their API URLs, and list of currency pairs to poll for each
exchanges = {}
pairs = {}

exchanges['bitfinex'] = 'https://api.bitfinex.com/v1/pubticker/'
pairs['bitfinex']     = ['bchbtc','ethbtc','dshbtc','xrpbtc','ltcbtc','bcheth']

exchanges['hitbtc']   = 'https://api.hitbtc.com/api/2/public/ticker/'
pairs['hitbtc']       = ['BCHBTC','ETHBTC','DASHBTC','XRPBTC','LTCBTC','BCHETH']

exchanges['kraken']   = 'https://api.kraken.com/0/public/Ticker?pair='
pairs['kraken']       = ['BCHXBT','ETHXBT','DASHXBT','XRPXBT','LTCXBT']

exchanges['bittrex']  = 'https://bittrex.com/api/v1.1/public/getticker?market='
pairs['bittrex']      = ['BTC-BCC','BTC-ETH','BTC-DASH','BTC-XRP','BTC-LTC','ETH-BCC','ETH-DASH']


# make dict with filename / URL pairs
fname_url = {}
for e, u in exchanges.items():
    for p in pairs[e]:
        fname_url[e+'_'+p+'.txt'] = u+p

# open file for each filename in the dict and store the file handle in a dict
filehandles = {}
for f, u in fname_url.items():
    filehandles[f] = open('./data/'+f,'a+')


sleepseconds = 46  # execution of all requests in loop averages about 14 seconds, so this repeats approx once per minute
#maxloopiterations = 10
i=0

# Loop until kill signal received or max query count reached
while True:

    try:
        i+=1
        log('polling all tickers',logfile)

        for f, u in fname_url.items():
            getTickerAndWrite(u,filehandles[f])

        log('sleeping for '+str(sleepseconds)+' seconds ...',logfile)
        time.sleep(sleepseconds)

    except:
        log('in except - caught kill signal',logfile)

        # close all open files
        log('closing all files', logfile)
        for f, fh in filehandles.items():
            fh.close()

        log('closing logfile', logfile)
        logfile.close()

        raise

    # if i>maxloopiterations:
    #     log('loop count exceeded max, breaking out of while loop', logfile)
    #     break


log('completed while loop',logfile)

# close all open files
log('closing all files', logfile)
for f, fh in filehandles.items():
    fh.close()

log('closing logfile', logfile)
logfile.close()


